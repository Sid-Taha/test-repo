export default [
  require("C:\\Users\\PMLS\\Desktop\\test-vercel\\hackathon-physical-ai-and-humanoid-robotics\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("C:\\Users\\PMLS\\Desktop\\test-vercel\\hackathon-physical-ai-and-humanoid-robotics\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("C:\\Users\\PMLS\\Desktop\\test-vercel\\hackathon-physical-ai-and-humanoid-robotics\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("C:\\Users\\PMLS\\Desktop\\test-vercel\\hackathon-physical-ai-and-humanoid-robotics\\src\\css\\custom.css"),
];
