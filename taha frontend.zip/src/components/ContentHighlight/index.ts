// src\components\ContentHighlight\index.ts
export { default } from './ContentHighlight';
